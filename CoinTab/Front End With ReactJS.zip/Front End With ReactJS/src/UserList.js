import { useEffect, useState } from "react";
import axios from "axios";
import React from "react";
import { useNavigate } from "react-router-dom";
import SingleUser from "./SingleUser";
import Register_User from "./RegisterUser";

export default function UserList() {
  let [status,setStatus] = useState(true);
  let [editStatus,setEditStatus] = useState(false);
  let [users,setUsers]=useState([]);
  let [uname,setUname]= useState("");
  let [id,SetId] = useState("");
  let [mail,setMail] = useState("");
  let [viewData,setViewData] =useState(false);
  let [singleUser,setSingleUser] = useState("");

  let [username,setUsername]=useState("");
  let [usermailId,setuserMailId] = useState("");
  let [userId,setuserId] = useState("");

  let [editMail,setEditMail] =useState("");
  let [editId,setEditId] = useState("");
  let [editUname,setEditUname] =useState("");
  let [editpass,setEditPass] = useState("");
  // const numbers = ["hii", "hello", "this", "is", "me"]; 

  let navigate=useNavigate();
  useEffect(()=>{

    // const user= JSON.parse(sessionStorage.getItem("mail_id"));
    
    // alert()
    getAllData();
    
},[])

function getAllData()
{

  setUname="name";
    SetId = "id";
    axios.post('http://localhost:8080/all/logins',{uname,id})
            .then(Response=>{
                if(Response.status===200)
                {
                  console.log(Response.data,"data grabbed")
                  localStorage.setItem("login_data",JSON.stringify(Response.data))
                  setUsers(JSON.parse(localStorage.getItem("login_data")))
                }else{
                    alert("Data Not Found")
                }
            })
            .catch(e=>{
              console.log(e)
              alert("Something went Wrong Try Again")
            })



}


function register()
{
  console.log(mail)

}
  
function viewFunction(id)
{

  console.log({id}," id seen");

  const user_name ="name";
  axios.post('http://localhost:8080/get/oneuser',{user_name,id})
          .then(Response=>{
              if(Response.status===200)
              {
                console.log(Response.data,"one user got")
                setStatus(false);
                localStorage.setItem("one_user",JSON.stringify(Response.data))
                setSingleUser(JSON.parse(localStorage.getItem("one_user")))
              }else{
                  alert("Data Not Found")
              }
          })
          .catch(e=>{
            console.log(e)
            alert("Something went Wrong Try Again")
          })
}

function EditFunction(eve)
{

  console.log(eve.id+"  ",eve.mail_id,"   ",eve.u_name,"    password is: ",eve.password);

  setEditStatus(true);
  setEditId(eve.id);
  setEditMail(eve.mail_id);
  setEditUname(eve.u_name);
  setEditPass(eve.password);

}


function addrecord()
{
  setEditStatus(false);
  console.log(editId,"  ",editMail,"   ",editUname,"   e password ",editpass)

  const id = editId;
  const mail_id = editMail;
  const u_name = editUname;
  const password= editpass;


  // console.log(editUserId,"  ",editUserMail,"   ",editUserName,"   data saved")

  axios.post('http://localhost:8080/add/update',{id,mail_id,u_name,password})//,editUserMail})
          .then(Response=>{
              if(Response.status===200)
              {
                alert(Response.data,"...! :)");
                getAllData();
               
              }else{
                  alert("Data not Saved")
              }
          })
          .catch(e=>{
            console.log(e)
            alert("Something went Wrong Try Again")
          })
//----------------------------------------------------------------------

}

function DeleteFunction(eve)
{

  // let text = "Are You sure to delete record...?";
  // if (window.confirm(text) == true) 
  // {
    
    setEditId(eve.id);
    console.log(editId);

    const id = editId;

    axios.post('http://localhost:8080/delete',{id})
          .then(Response=>{
              if(Response.status===200)
              {
                alert(Response.data,"...! :)");
                getAllData();
               
              }else{
                  alert("Data not Deleted")
              }
          })
          .catch(e=>{
            console.log(e)
            alert("Something went Wrong Try Again")
          })

  // } 
  // else 
  // {
  //     navigate("/user/list");
  // }



}



// function goBack()
// {

  


// }

  if(status)
  {

    return (
      <>
            <div>
           
              <div >
                <br />
                <br />
                <br />
                <br />
                <center>
                <h2>USERS TABLE</h2>
  
                <table border="1">
                <thead>
                <tr>
                  <th>ID</th>
                  <th>USERNAME</th>
                  <th>MAIL_ID</th>
                  <th>ACTIONS</th>
                </tr>  
                </thead>
  
                <tbody>
  
                  {users.map((eve)=>{
                  return( 
                    
                    <tr>
                      <td>{eve.id}</td>
                      <td>{eve.u_name}</td>
                      <td>{eve.mail_id}</td>
                      <td>&nbsp;&nbsp;<button onClick={()=>viewFunction(eve.id)}>VIEW</button>
                          &nbsp; || &nbsp;<button onClick={()=>EditFunction(eve)}>EDIT</button>
                          &nbsp; || &nbsp;<button onClick={()=>DeleteFunction(eve)} >DELETE</button>&nbsp;&nbsp;</td>
                    </tr>   

                    );
  
                })}
  
                </tbody>
                </table>
                
              <div>
                {
                  editStatus?
                  <div>
                    <br/><br/>
                    Update userID: <input type="number" value={editId} readOnly onChange={(eve)=>setEditId(eve.target.value)}></input>
                    Update Username : <input type="text" value={editUname} onChange={(eve)=>setEditUname(eve.target.value)}></input>
                    Update MailID : <input type="email" value={editMail} onChange={(eve)=>setEditMail(eve.target.value)}></input><br/><br/><br/>

                    <button onClick={()=>addrecord()}>Submit Changes</button>

                  </div>:
                  <h1></h1>
                }
              </div>


                </center>
              </div>
            </div>
      </>
    );


  }
  else
  {
    return(

      <div>
        
        <center>
          <br/><br/><br/>
    <h1> User Name: {singleUser.u_name} |  User Email-Id: {singleUser.mail_id}</h1>
        
        </center>

      </div>

    );

  }
  
}