//import react from 'react';
import { useState } from "react"
import axios from "axios";
import { Navigate } from "react-router-dom";
import { useNavigate } from "react-router"

function LoginUser()
{
    let [mail_id,setMail_id] = useState("");
    let [password,setPassword] = useState("");
    let navigate = useNavigate()
    
    function loginhandler()
    {
        console.log(mail_id);
        console.log(password)

        axios.post('http://localhost:8080/login/get',{mail_id,password})
        .then( data=>
            {
                console.log(data.data)
                if(data.data === "login success")
                {
                    // alert("Login Successful")
                    
                    sessionStorage.setItem('mail_id',JSON.stringify(mail_id));
                    alert("Welcome "+JSON.parse(sessionStorage.getItem("mail_id")));
                    navigate("/user/list")
                }
                else if(data.data === "you are blocked for 24 hours"){

                    alert("you are blocked for 24 hours")
                    navigate("/")
                }
                else if(data.data === "you are blocked"){

                    alert("you are blocked")
                    navigate("/")
                }
                else {

                    alert("Invalid credentials")
                    navigate("/")
                }
            }
             

        );

    }

    // function showuser()
    // {
    //     const numbers = ["hii", "hello", "this", "is", "me"]; 
    //     const doubled = numbers.map((number) => number);
    //     console.log(doubled);

    // }

   


    return(

        <div>

        <left>
        {/* <a href="/new/user" >Register Yourself</a> */}
        <br></br><br></br><br></br>
        {/* <button  onClick={showuser} >SHOW LIST</button> */}

        <a href="/new/user" >Add User</a>
        </left>

            <center>
                <p>
        Enter Mail-ID : <input type="email" placeholder="Email-Id" onBlur={(e)=>{setMail_id(e.target.value)}} /><br></br><br></br><br></br>
        Enter Password : <input type="text" placeholder="Password" onBlur={(e)=>{setPassword(e.target.value)} } /><br></br><br></br><br></br>
        <button onClick={loginhandler} >Login</button>
        </p>
        </center>

        </div>
    );
}

export default LoginUser;