// import { useDispatch} from "react-redux"
import React from "react";
import { useNavigate } from "react-router-dom";
export default function SingleUser(props) {
 
  const u_name = props.name;
  const mail_id = props.mail_id;
  const password = props.password;

  //const dispatch= useDispatch()
  let navigate=useNavigate();
  // function handler1()
  // {
  //   //dispatch({type:"doctor_select",payload:{doctor_id:id,clinic_id:clinic_id}})
  //   sessionStorage.setItem('doctor_select',JSON.stringify({doctor_id:id,clinic_id:clinic_id,clinic_name:clinic,doctor_name:name}))
  //   navigate('/Appointment');
  // }


  return (

    <div>
      <center>
        
    <table border="2" bgcolor="white">
      <tr>
          <td>
            <center>
          {u_name}
          </center>
          </td>
          <td>
            <center>
          {mail_id}
          </center>
          </td>
          <td>
          <center>
          <button>VIEW</button> || <button>UPDATE</button> || <button>DELETE</button>
          </center>
          </td>
          
      </tr>

    </table>


    {/* <h4>{name}</h4><br></br> */}
    </center>

    </div>
    
  );
}
