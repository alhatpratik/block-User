package demoAPI;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CointabApplicationTests {

	@Test
	void contextLoads() {
	}

}
