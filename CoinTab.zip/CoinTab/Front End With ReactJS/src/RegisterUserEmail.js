// import React from "react"

import { useState, useEffect } from "react";
import axios from "axios";
import { Navigate } from "react-router-dom";
import { useNavigate } from "react-router"
import LoginUser from "./login";

export default function Register_User()
{
    useEffect(()=>{

        let [user,setUser] = useState("");
        setUser(JSON.parse(sessionStorage.getItem("mail_id")));

    },[])


    if(user !== null)
    {

    let [u_name,setU_name] = useState("");
    let [mail_id,setMail_id] = useState("");
    let [password,setPassword] = useState("");
    let [confirm,setConfirm] = useState("");
    let navigate = useNavigate();

    
    function registerHandler()
    {

        console.log(u_name)
        console.log(mail_id)
        console.log(password)
        
        if(password === confirm)
        {

            axios.post("http://localhost:8080/adduser",{u_name,mail_id,password})
            .then(data=>
            {
                console.log(data.data)

                if(data.data === "registered successful")
                {
                    alert("created success")
                    navigate("/")
                }
                else
                {
                    console.log("else block")
                    navigate("/new/user")
                }
                
            }
        );

        }
        else
        {
            alert("password not matched");
            navigate("/new/user")
        }
        
    }


        return(
            <div>
    
            <br></br>
                
                <center>
                Enter Username: <input type="text" placeholder="Username" onBlur={(e)=>{setU_name(e.target.value)}}></input><br></br><br></br>
                Enter Mail-ID  : <input type="email" value={mail} placeholder="Email-ID" onBlur={(e)=>{setMail_id(e.target.value)}}></input><br></br><br></br>
                Enter Password: <input type="text" placeholder="Password" onBlur={(e)=>{setPassword(e.target.value)}}></input><br></br><br></br>
                Confirm Password: <input type="text" placeholder="Confirm Password" onBlur={(e)=>{setConfirm(e.target.value)}}></input><br></br><br></br>
                <button onClick={registerHandler}>Register Myself</button>
                
                </center>
            </div>
    
            );
    
        }


    }
    else
    {
        <div>
        alert("Login First ... you are not allowed to do this..!");
        navigate("/");
        </div>
    }
   